var themeHeader = {
  name: 'Dark',
  author: 'MERN-stack-CMS',
};

var themeOptions = {
  palette: {
    type: 'dark',
  },
};
