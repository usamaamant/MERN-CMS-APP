export const WidgetTypes = { MOVE: 'move' };
