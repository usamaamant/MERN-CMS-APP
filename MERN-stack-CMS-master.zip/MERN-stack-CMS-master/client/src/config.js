// Server API Root URL
export const SERVER_ROOT_URL = 'http://localhost:3001';
